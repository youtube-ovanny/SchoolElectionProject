﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Button1 = New Button()
        PictureBox4 = New PictureBox()
        PictureBox3 = New PictureBox()
        PictureBox2 = New PictureBox()
        PictureBox1 = New PictureBox()
        Label1 = New Label()
        Button2 = New Button()
        Button3 = New Button()
        Button4 = New Button()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.Brown
        Button1.Font = New Font("Candara", 18F)
        Button1.Location = New Point(131, 78)
        Button1.Name = "Button1"
        Button1.Size = New Size(235, 37)
        Button1.TabIndex = 0
        Button1.Text = "View Candidates"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' PictureBox4
        ' 
        PictureBox4.BackColor = Color.DarkRed
        PictureBox4.Location = New Point(-18, -7)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(532, 35)
        PictureBox4.TabIndex = 9
        PictureBox4.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.BackColor = Color.DarkRed
        PictureBox3.Location = New Point(-1, -28)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(35, 452)
        PictureBox3.TabIndex = 8
        PictureBox3.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackColor = Color.DarkRed
        PictureBox2.Location = New Point(-30, 332)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(532, 35)
        PictureBox2.TabIndex = 7
        PictureBox2.TabStop = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.DarkRed
        PictureBox1.Location = New Point(450, -3)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(35, 370)
        PictureBox1.TabIndex = 6
        PictureBox1.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Brown
        Label1.Font = New Font("Candara", 18F)
        Label1.Location = New Point(212, 31)
        Label1.Name = "Label1"
        Label1.Size = New Size(71, 29)
        Label1.TabIndex = 10
        Label1.Text = "Menu"
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.Brown
        Button2.Font = New Font("Candara", 18F)
        Button2.Location = New Point(131, 136)
        Button2.Name = "Button2"
        Button2.Size = New Size(235, 37)
        Button2.TabIndex = 11
        Button2.Text = "Vote For Candidates"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.Brown
        Button3.Font = New Font("Candara", 18F)
        Button3.Location = New Point(131, 200)
        Button3.Name = "Button3"
        Button3.Size = New Size(235, 37)
        Button3.TabIndex = 12
        Button3.Text = "View Results"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Button4
        ' 
        Button4.BackColor = Color.Brown
        Button4.Font = New Font("Candara", 18F)
        Button4.Location = New Point(131, 260)
        Button4.Name = "Button4"
        Button4.Size = New Size(235, 37)
        Button4.TabIndex = 13
        Button4.Text = "Exit Program"
        Button4.UseVisualStyleBackColor = False
        ' 
        ' MainMenu
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Brown
        ClientSize = New Size(484, 361)
        Controls.Add(Button2)
        Controls.Add(Label1)
        Controls.Add(PictureBox4)
        Controls.Add(PictureBox3)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox1)
        Controls.Add(Button3)
        Controls.Add(Button1)
        Controls.Add(Button4)
        Name = "MainMenu"
        Text = "MainMenu"
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
End Class
