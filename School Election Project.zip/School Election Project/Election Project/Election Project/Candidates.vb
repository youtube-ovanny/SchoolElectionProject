﻿Public Class Candidates
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Hide()
        MainMenu.Show() ' returns to menu
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Label2.Visible = False 'hides everything in the middle,
        Label3.Visible = False 'asking them to vote
        PictureBox2.Visible = False 'Valorant Logo
        Label7.Visible = False ' gekko text
        Label8.Visible = False ' cypher text
        Label8.Visible = False ' Co President text
        Button7.Visible = False 'gekko voiceline
        Button8.Visible = False ' cypher voiceline


        PictureBox3.Image = My.Resources.raze ' sets picture to raze
        PictureBox4.Image = My.Resources.skye ' sets picture to skye
        PictureBox3.Visible = True 'Raze
        PictureBox4.Visible = True 'Skye
        Label4.Visible = True 'President text
        Label5.Visible = True 'Raze text
        Label6.Visible = True ' Skye text
        Button5.Visible = True ' Raze Voiceline
        Button6.Visible = True ' Skye Voiceline

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        My.Computer.Audio.Play(My.Resources.RazeVoiceLine, AudioPlayMode.Background) ' plays raze voiceline

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        My.Computer.Audio.Play(My.Resources.SkyeVoiceline, AudioPlayMode.Background) ' plays skye voiceline
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Label5.Visible = False 'Raze text
        Label6.Visible = False ' Skye text
        Button5.Visible = False ' Raze Voiceline
        Button6.Visible = False ' Skye Voiceline
        Label5.Visible = False 'Raze text
        Label6.Visible = False ' Skye text
        Button5.Visible = False ' Raze Voiceline
        Button6.Visible = False ' Skye Voiceline
        Label4.Visible = False 'President text


        Label7.Visible = True ' gekko text
        Label8.Visible = True ' cypher text
        Button7.Visible = True ' gekko voiceline
        Button8.Visible = True ' cypher voiceline
        Label9.Visible = True ' Co-President text
        PictureBox3.Image = My.Resources.gekko ' gekko icon
        PictureBox4.Image = My.Resources.cypher ' cypher icon

    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        My.Computer.Audio.Play(My.Resources.GekkoVoiceline, AudioPlayMode.Background) ' plays gekko voiceline

    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        My.Computer.Audio.Play(My.Resources.CypherVoiceLine, AudioPlayMode.Background) ' plays cypher voiceline

    End Sub
End Class