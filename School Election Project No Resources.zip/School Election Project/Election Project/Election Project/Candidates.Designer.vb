﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Candidates
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Candidates))
        PictureBox1 = New PictureBox()
        Button1 = New Button()
        Button2 = New Button()
        Button3 = New Button()
        Label1 = New Label()
        Button4 = New Button()
        Label2 = New Label()
        PictureBox2 = New PictureBox()
        Label3 = New Label()
        PictureBox3 = New PictureBox()
        PictureBox4 = New PictureBox()
        Label4 = New Label()
        Label6 = New Label()
        Button5 = New Button()
        Button6 = New Button()
        Button7 = New Button()
        Button8 = New Button()
        Label5 = New Label()
        Label7 = New Label()
        Label8 = New Label()
        Label9 = New Label()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.DarkRed
        PictureBox1.Location = New Point(-2, -14)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(128, 415)
        PictureBox1.TabIndex = 7
        PictureBox1.TabStop = False
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.DarkRed
        Button1.Font = New Font("Yu Gothic", 14F)
        Button1.Location = New Point(2, 63)
        Button1.Name = "Button1"
        Button1.Size = New Size(122, 43)
        Button1.TabIndex = 8
        Button1.Text = "President"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.DarkRed
        Button2.Font = New Font("Yu Gothic", 12F)
        Button2.Location = New Point(2, 162)
        Button2.Name = "Button2"
        Button2.Size = New Size(122, 43)
        Button2.TabIndex = 9
        Button2.Text = "Co-President"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.DarkRed
        Button3.Font = New Font("Yu Gothic", 12F)
        Button3.Location = New Point(4, 280)
        Button3.Name = "Button3"
        Button3.Size = New Size(122, 43)
        Button3.TabIndex = 10
        Button3.Text = "Button3"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.DarkRed
        Label1.Font = New Font("Yu Gothic", 15F)
        Label1.Location = New Point(3, 2)
        Label1.Name = "Label1"
        Label1.Size = New Size(117, 26)
        Label1.TabIndex = 11
        Label1.Text = "Candidates"
        ' 
        ' Button4
        ' 
        Button4.BackColor = Color.DarkRed
        Button4.Font = New Font("Calibri", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button4.Location = New Point(422, 2)
        Button4.Name = "Button4"
        Button4.Size = New Size(57, 25)
        Button4.TabIndex = 12
        Button4.Text = "Menu"
        Button4.UseVisualStyleBackColor = False
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Yu Gothic", 17F)
        Label2.Location = New Point(130, 30)
        Label2.Name = "Label2"
        Label2.Size = New Size(344, 60)
        Label2.TabIndex = 13
        Label2.Text = "Check out all of our candidates" & vbCrLf & "         for each category!" & vbCrLf
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(228, 95)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(146, 103)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 14
        PictureBox2.TabStop = False
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Yu Gothic", 17F)
        Label3.Location = New Point(130, 223)
        Label3.Name = "Label3"
        Label3.Size = New Size(348, 90)
        Label3.TabIndex = 15
        Label3.Text = "After viewing all the candidates" & vbCrLf & "        return to the menu" & vbCrLf & "       and make your vote!"
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Location = New Point(132, 69)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(114, 92)
        PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox3.TabIndex = 16
        PictureBox3.TabStop = False
        PictureBox3.Visible = False
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Location = New Point(132, 240)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(114, 99)
        PictureBox4.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox4.TabIndex = 17
        PictureBox4.TabStop = False
        PictureBox4.Visible = False
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Transparent
        Label4.Font = New Font("Yu Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(218, 9)
        Label4.Name = "Label4"
        Label4.Size = New Size(119, 31)
        Label4.TabIndex = 18
        Label4.Text = "President"
        Label4.Visible = False
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Yu Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(164, 212)
        Label6.Name = "Label6"
        Label6.Size = New Size(54, 25)
        Label6.TabIndex = 20
        Label6.Text = "Skye"
        Label6.Visible = False
        ' 
        ' Button5
        ' 
        Button5.BackColor = Color.DarkRed
        Button5.Font = New Font("Yu Gothic", 15.75F)
        Button5.Location = New Point(252, 118)
        Button5.Name = "Button5"
        Button5.Size = New Size(205, 43)
        Button5.TabIndex = 21
        Button5.Text = "Raze's Quote"
        Button5.UseVisualStyleBackColor = False
        Button5.Visible = False
        ' 
        ' Button6
        ' 
        Button6.BackColor = Color.DarkRed
        Button6.Font = New Font("Yu Gothic", 15.75F)
        Button6.Location = New Point(252, 296)
        Button6.Name = "Button6"
        Button6.Size = New Size(205, 43)
        Button6.TabIndex = 22
        Button6.Text = "Skye's Quote"
        Button6.UseVisualStyleBackColor = False
        Button6.Visible = False
        ' 
        ' Button7
        ' 
        Button7.BackColor = Color.DarkRed
        Button7.Font = New Font("Yu Gothic", 15.75F)
        Button7.Location = New Point(252, 118)
        Button7.Name = "Button7"
        Button7.Size = New Size(205, 43)
        Button7.TabIndex = 23
        Button7.Text = "Gekko's Quote"
        Button7.UseVisualStyleBackColor = False
        Button7.Visible = False
        ' 
        ' Button8
        ' 
        Button8.BackColor = Color.DarkRed
        Button8.Font = New Font("Yu Gothic", 15.75F)
        Button8.Location = New Point(252, 296)
        Button8.Name = "Button8"
        Button8.Size = New Size(205, 43)
        Button8.TabIndex = 24
        Button8.Text = "Cypher's Quote"
        Button8.UseVisualStyleBackColor = False
        Button8.Visible = False
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Yu Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(161, 41)
        Label5.Name = "Label5"
        Label5.Size = New Size(56, 25)
        Label5.TabIndex = 19
        Label5.Text = "Raze"
        Label5.Visible = False
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Yu Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(153, 41)
        Label7.Name = "Label7"
        Label7.Size = New Size(68, 25)
        Label7.TabIndex = 25
        Label7.Text = "Gekko"
        Label7.Visible = False
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Yu Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label8.Location = New Point(155, 212)
        Label8.Name = "Label8"
        Label8.Size = New Size(74, 25)
        Label8.TabIndex = 26
        Label8.Text = "Cypher"
        Label8.Visible = False
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.BackColor = Color.Transparent
        Label9.Font = New Font("Yu Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label9.Location = New Point(197, 9)
        Label9.Name = "Label9"
        Label9.Size = New Size(158, 31)
        Label9.TabIndex = 27
        Label9.Text = "Co-President"
        Label9.Visible = False
        ' 
        ' Candidates
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Brown
        ClientSize = New Size(484, 361)
        Controls.Add(Button1)
        Controls.Add(Label4)
        Controls.Add(Label7)
        Controls.Add(Button8)
        Controls.Add(Button7)
        Controls.Add(Label3)
        Controls.Add(PictureBox2)
        Controls.Add(Label2)
        Controls.Add(Button4)
        Controls.Add(Label1)
        Controls.Add(Button2)
        Controls.Add(Button5)
        Controls.Add(Label5)
        Controls.Add(PictureBox4)
        Controls.Add(PictureBox3)
        Controls.Add(Button6)
        Controls.Add(Label8)
        Controls.Add(Label6)
        Controls.Add(Label9)
        Controls.Add(Button3)
        Controls.Add(PictureBox1)
        Name = "Candidates"
        Text = " "
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Button4 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
End Class
